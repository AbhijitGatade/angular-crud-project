import { Component, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/product.service';

@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css']
})
export class ProductCreateComponent implements OnInit {

  product = {
    id: 0,
    name: '',
    mrp: 0,
    price: 0,
    available: 'Yes'
  };

  submitted = false;

  constructor(private productService: ProductService) { }

  ngOnInit(): void {
  }

  createProduct(): void{
    const data = {
      id: 0,
      name: this.product.name,
      mrp:  this.product.mrp,
      price: this.product.price,
      available: this.product.available
    };
    console.log(data);
    // this.productService.create(data).subscribe(
    //   response=>{
    //     console.log(response);
    //     this.submitted = true;
    //   },
    //   error=>{
    //     console.log(error);
    //   }
    // );
  }

  newProduct(): void{
    this.submitted = false;
    this.product = {
      id: 0,
      name: '',
      mrp: 0,
      price: 0,
      available: 'Yes'
    };
  }

}
