import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

//const baseURL = 'http://localhost/crudproject/api';
const baseURL = 'https://angularcrud.igaptechnologies.com/api';


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  constructor(private httlClient: HttpClient) { }

  readAll(): Observable<any>{
    return this.httlClient.post(baseURL + "/listproducts", null);
  }

  read(id: any): Observable<any>{
    return this.httlClient.post(baseURL + "/getproduct", null);
  }

  create(data:any): Observable<any>{
    return this.httlClient.post(baseURL + "/saveproduct", data);
  }

  update(data:any): Observable<any>{
    return this.httlClient.post(baseURL + "/saveproduct", data);
  }

  delete(id: any): Observable<any>{
    return this.httlClient.post(baseURL + "/deleteproduct", null);
  }
}
