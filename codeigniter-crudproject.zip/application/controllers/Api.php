<?php
   
require APPPATH . 'libraries/REST_Controller.php';
     
class Api extends REST_Controller {
    
	  /**
     * Get All Data from this method.
     *
     * @return Response
    */
    public function __construct() {

      header('Access-Control-Allow-Origin: *');
      header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");

       parent::__construct();
       $this->load->database();
       $this->load->model("ProductModel", "product");
    }

    public function saveproduct_post(){
      $this->product->save();
      // $data["result"] = "success";
      // $this->response($data, 200);      
   }

   public function listproducts_post(){
      $data["products"] = $this->product->lists();
      $this->response($data, 200);
   }

   public function deleteproduct_post(){
      $id = $this->input->post("id");
      $this->product->delete($id);
      $data["result"] = "success";
      $this->response($data, 200);
   }

   public function getproduct_post(){
      $id = $this->input->post("id");
      $data["product"] = $this->product->getbyid($id);
      $this->response($data, 200);		
   }
}