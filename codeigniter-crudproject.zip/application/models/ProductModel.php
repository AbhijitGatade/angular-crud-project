<?php
    defined('BASEPATH') OR exut('No direct script access allowed');

class ProductModel extends CI_Model {

    public function __construct(){
        $this->load->database();
    }

    public function save(){
        $obj = file_get_contents('php://input');
        $edata = json_decode($obj);
        echo $obj;
        // $field = array(
        //     'name'=>$this->input->post("name"),
        //     'mrp'=>$this->input->post("mrp"),
        //     'price'=>$this->input->post("price"),
        //     'available'=>$this->input->post("available"),
        // );
        // $id = $this->input->post("id");
        // if($id == 0){
        //     $this->db->insert("products", $field);
        //     $id = $this->db->insert_id();
        // }
        // else{
        //     $this->db->where("id", $id);
        //     $this->db->update("products", $field);
        // }
    }

    public function lists(){
        $data = $this->db->get("products");
        return $data->result();
    }

    public function getbyid($id){
        $this->db->where("id", $id);
        $data = $this->db->get("products");
        return $data->row();
    }

    public function delete($id){
        $this->db->where("id", $id);
        $this->db->delete("products");
    }
}